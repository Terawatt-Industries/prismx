/*
 * WINREG.java
 *
 * Created on 17. August 2007, 14:32
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package processing.app.windows;

/**
 *
 * @author TB
 */
public interface WINREG {
  public final static int HKEY_CLASSES_ROOT = 0x80000000;
  public final static int HKEY_CURRENT_USER = 0x80000001;
  public final static int HKEY_LOCAL_MACHINE = 0x80000002;
  public final static int HKEY_USERS = 0x80000003;
}

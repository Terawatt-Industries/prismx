/*
 * by Shigeru KANEMOTO at SWITCHSCIENCE.
 * on 2011-10-15
 */

package processing.app;
import java.util.ListResourceBundle;

public class Resources extends ListResourceBundle {
  protected Object[][] getContents() {
    return new Object[][] {};	// Empty
  }
}
